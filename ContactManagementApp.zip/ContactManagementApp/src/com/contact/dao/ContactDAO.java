package com.contact.dao;

import java.util.List;
import com.contact.model.Contact;

public interface ContactDAO {
    void addContact(Contact contact);
    List<Contact> getAllContacts();
    void updateContact(Contact contact);
    void deleteContact(int id);
}