package com.contact.dao;

import java.sql.*;
import java.util.*;
import com.contact.model.Contact;
import com.contact.util.DBConnection;

public class ContactDAOImpl implements ContactDAO {

    public void addContact(Contact c) {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO contacts(name,email,phone) VALUES(?,?,?)"
            );
            ps.setString(1, c.getName());
            ps.setString(2, c.getEmail());
            ps.setString(3, c.getPhone());
            ps.executeUpdate();
            System.out.println("Contact Added!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Contact> getAllContacts() {
        List<Contact> list = new ArrayList<>();
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM contacts");

            while (rs.next()) {
                Contact c = new Contact();
                c.setId(rs.getInt("id"));
                c.setName(rs.getString("name"));
                c.setEmail(rs.getString("email"));
                c.setPhone(rs.getString("phone"));
                list.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void updateContact(Contact c) {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "UPDATE contacts SET name=?, email=?, phone=? WHERE id=?"
            );
            ps.setString(1, c.getName());
            ps.setString(2, c.getEmail());
            ps.setString(3, c.getPhone());
            ps.setInt(4, c.getId());
            ps.executeUpdate();
            System.out.println("Contact Updated!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteContact(int id) {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "DELETE FROM contacts WHERE id=?"
            );
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Contact Deleted!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}