package com.contact.main;

import java.util.*;
import com.contact.dao.*;
import com.contact.model.Contact;

public class MainApp {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ContactDAO dao = new ContactDAOImpl();

        while (true) {
            System.out.println("\n1.Add 2.View 3.Update 4.Delete 5.Exit");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    Contact c = new Contact();
                    sc.nextLine();
                    System.out.print("Name: ");
                    c.setName(sc.nextLine());
                    System.out.print("Email: ");
                    c.setEmail(sc.nextLine());
                    System.out.print("Phone: ");
                    c.setPhone(sc.nextLine());
                    dao.addContact(c);
                    break;

                case 2:
                    dao.getAllContacts().forEach(x ->
                        System.out.println(x.getId()+" "+x.getName()+" "+x.getEmail()+" "+x.getPhone())
                    );
                    break;

                case 3:
                    Contact u = new Contact();
                    System.out.print("ID: ");
                    u.setId(sc.nextInt());
                    sc.nextLine();
                    System.out.print("New Name: ");
                    u.setName(sc.nextLine());
                    System.out.print("New Email: ");
                    u.setEmail(sc.nextLine());
                    System.out.print("New Phone: ");
                    u.setPhone(sc.nextLine());
                    dao.updateContact(u);
                    break;

                case 4:
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    dao.deleteContact(id);
                    break;

                case 5:
                    System.exit(0);
            }
        }
    }
}