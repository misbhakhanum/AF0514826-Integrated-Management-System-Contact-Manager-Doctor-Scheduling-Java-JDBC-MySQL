package com.doctor.dao;

import java.util.List;
import com.doctor.model.Appointment;

public interface AppointmentDAO {
    void addAppointment(Appointment a);
    List<Appointment> getAppointments();
    void deleteAppointment(int id);
}