package com.doctor.dao;

import java.sql.*;
import java.util.*;
import com.doctor.model.Appointment;
import com.doctor.util.DBConnection;

public class AppointmentDAOImpl implements AppointmentDAO {

    public void addAppointment(Appointment a) {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO appointments(doctor_id, patient_name, appointment_date) VALUES(?,?,?)"
            );
            ps.setInt(1, a.getDoctorId());
            ps.setString(2, a.getPatientName());
            ps.setDate(3, a.getAppointmentDate());
            ps.executeUpdate();
            System.out.println("Appointment Booked!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Appointment> getAppointments() {
        List<Appointment> list = new ArrayList<>();
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM appointments");

            while (rs.next()) {
                Appointment a = new Appointment();
                a.setId(rs.getInt("id"));
                a.setDoctorId(rs.getInt("doctor_id"));
                a.setPatientName(rs.getString("patient_name"));
                a.setAppointmentDate(rs.getDate("appointment_date"));
                list.add(a);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void deleteAppointment(int id) {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "DELETE FROM appointments WHERE id=?"
            );
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Appointment Deleted!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}