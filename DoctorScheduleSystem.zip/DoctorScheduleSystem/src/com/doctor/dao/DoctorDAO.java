package com.doctor.dao;

import java.util.List;
import com.doctor.model.Doctor;

public interface DoctorDAO {
    void addDoctor(Doctor d);
    List<Doctor> getAllDoctors();
} 