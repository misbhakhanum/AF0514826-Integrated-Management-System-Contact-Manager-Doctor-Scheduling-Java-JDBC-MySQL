package com.doctor.dao;

import java.sql.*;
import java.util.*;
import com.doctor.model.Doctor;
import com.doctor.util.DBConnection;

public class DoctorDAOImpl implements DoctorDAO {

    public void addDoctor(Doctor d) {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO doctors(name, specialization) VALUES(?,?)"
            );
            ps.setString(1, d.getName());
            ps.setString(2, d.getSpecialization());
            ps.executeUpdate();
            System.out.println("Doctor Added!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Doctor> getAllDoctors() {
        List<Doctor> list = new ArrayList<>();
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM doctors");

            while (rs.next()) {
                Doctor d = new Doctor();
                d.setId(rs.getInt("id"));
                d.setName(rs.getString("name"));
                d.setSpecialization(rs.getString("specialization"));
                list.add(d);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}