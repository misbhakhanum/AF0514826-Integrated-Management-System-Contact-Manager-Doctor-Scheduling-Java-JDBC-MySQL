package com.doctor.main;

import java.util.*;
import java.sql.Date;
import com.doctor.dao.*;
import com.doctor.model.*;

public class MainApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        DoctorDAO doctorDAO = new DoctorDAOImpl();
        AppointmentDAO appointmentDAO = new AppointmentDAOImpl();

        while (true) {
            System.out.println("\n1.Add Doctor");
            System.out.println("2.View Doctors");
            System.out.println("3.Book Appointment");
            System.out.println("4.View Appointments");
            System.out.println("5.Delete Appointment");
            System.out.println("6.Exit");

            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    Doctor d = new Doctor();
                    sc.nextLine();
                    System.out.print("Doctor Name: ");
                    d.setName(sc.nextLine());
                    System.out.print("Specialization: ");
                    d.setSpecialization(sc.nextLine());
                    doctorDAO.addDoctor(d);
                    break;

                case 2:
                    doctorDAO.getAllDoctors().forEach(doc ->
                        System.out.println(doc.getId() + " " + doc.getName() + " " + doc.getSpecialization())
                    );
                    break;

                case 3:
                    Appointment a = new Appointment();
                    System.out.print("Doctor ID: ");
                    a.setDoctorId(sc.nextInt());
                    sc.nextLine();
                    System.out.print("Patient Name: ");
                    a.setPatientName(sc.nextLine());
                    System.out.print("Date (YYYY-MM-DD): ");
                    a.setAppointmentDate(Date.valueOf(sc.nextLine()));
                    appointmentDAO.addAppointment(a);
                    break;

                case 4:
                    appointmentDAO.getAppointments().forEach(app ->
                        System.out.println(app.getId() + " DoctorID:" + app.getDoctorId() +
                                " Patient:" + app.getPatientName() +
                                " Date:" + app.getAppointmentDate())
                    );
                    break;

                case 5:
                    System.out.print("Enter Appointment ID: ");
                    int id = sc.nextInt();
                    appointmentDAO.deleteAppointment(id);
                    break;

                case 6:
                    System.exit(0);
            }
        }
    }
}