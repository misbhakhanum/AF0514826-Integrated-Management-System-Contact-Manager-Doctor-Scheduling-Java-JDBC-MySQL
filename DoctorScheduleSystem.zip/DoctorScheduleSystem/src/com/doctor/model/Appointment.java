package com.doctor.model;

import java.sql.Date;

public class Appointment {

    private int id;
    private int doctorId;
    private String patientName;
    private Date appointmentDate;

    // Getter for id
    public int getId() {
        return id;
    }

    // Setter for id
    public void setId(int id) {
        this.id = id;
    }

    // Getter for doctorId
    public int getDoctorId() {
        return doctorId;
    }

    // Setter for doctorId
    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    // Getter for patientName
    public String getPatientName() {
        return patientName;
    }

    // Setter for patientName
    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    // Getter for appointmentDate
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // Setter for appointmentDate
    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }
}